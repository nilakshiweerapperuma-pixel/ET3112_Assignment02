import cv2 as cv
import matplotlib.pyplot as plt

img = cv.imread('crop_field.jpg', 0)

if img is None:
    print("Error: image not found.")
    exit()

edges = cv.Canny(img, 550, 690)

plt.subplot(1, 2, 1)
plt.imshow(img, cmap='gray')
plt.title("Original Image")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(edges, cmap='gray')
plt.title("Canny Edge Output")
plt.axis("off")

plt.savefig("q1.png")
plt.show()