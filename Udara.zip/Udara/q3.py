import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

img = cv.imread('crop_field.jpg', 0)

if img is None:
    print("Error: image not found")
    exit()

edges = cv.Canny(img, 550, 690)

indices = np.where(edges != 0)
x = indices[1]
y = indices[0]

if len(x) < 2:
    print("Not enough edge points for line fitting")
    exit()

m, c = np.polyfit(x, y, 1)
y_fit = m * x + c

plt.scatter(x, y, s=1)
plt.plot(x, y_fit, color='red')

plt.title("Least Squares Fit")
plt.xlabel("X")
plt.ylabel("Y")
plt.gca().invert_yaxis()

plt.savefig("q3.png")
plt.show()