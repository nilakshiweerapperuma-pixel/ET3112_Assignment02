import cv2 as cv
import numpy as np

img = cv.imread('crop_field.jpg', 0)

if img is None:
    print("Error: image not found")
    exit()

edges = cv.Canny(img, 100, 200)

indices = np.where(edges != 0)
x = indices[1]
y = indices[0]

if len(x) < 2:
    print("Not enough edge points to estimate angle")
    exit()

m, c = np.polyfit(x, y, 1)

theta = np.degrees(np.arctan(m))

print("Estimated Crop Angle (Least Squares):", theta, "degrees")