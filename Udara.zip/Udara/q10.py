import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

img = cv.imread('crop_field.jpg', 0)

if img is None:
    print("Error: image not found")
    exit()

edges = cv.Canny(img, 550, 690)

indices = np.where(edges != 0)
x = indices[1]
y = indices[0]

if len(x) < 2:
    print("Not enough edge points")
    exit()

points = np.column_stack((x, y))
mean = np.mean(points, axis=0)

centered = points - mean

U, S, Vt = np.linalg.svd(centered)
direction = Vt[0]

if abs(direction[0]) < 1e-10:
    print("The fitted line is nearly vertical")
    exit()

m_tls = direction[1] / direction[0]
c_tls = mean[1] - m_tls * mean[0]

theta_tls = np.degrees(np.arctan(m_tls))
print(f"Estimated Crop Angle (TLS): {theta_tls:.2f} degrees")

sort_idx = np.argsort(x)
x_sorted = x[sort_idx]
y_tls = m_tls * x_sorted + c_tls

plt.scatter(x, y, s=1)
plt.plot(x_sorted, y_tls, color='green')
plt.gca().invert_yaxis()
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Total Least Squares")

plt.savefig("q6.png")
plt.show()