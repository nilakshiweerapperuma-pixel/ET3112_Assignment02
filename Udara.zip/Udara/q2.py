import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

img = cv.imread('crop_field.jpg', 0)

if img is None:
    print("Error: Image not found")
    exit()

edges = cv.Canny(img, 550, 690)

indices = np.where(edges != 0)
x = indices[1]
y = indices[0]

plt.figure(figsize=(6,6))
plt.scatter(x, y, s=1)
plt.gca().invert_yaxis()   # 🔥 Fix orientation
plt.title("Scatter Plot of Edge Points")
plt.xlabel("X")
plt.ylabel("Y")

plt.savefig("q2.png")
plt.show()